IRIS Android app project — exact user-provided logo

This project wraps your hosted IRIS website in an Android WebView app.
It removes the browser's address bar, tabs and browser navigation controls.
The Android system status and navigation bars remain visible.

Website loaded:
https://capable-naiad-01afb2.netlify.app/

APP ICON:
The launcher icon assets have been replaced with a crop of your exact supplied
28745.jpg image: the purple rounded-square tile and spaced white "I r I s" letters.
The "IRIS" caption below the tile is excluded because Android shows the app name
under its launcher icon automatically.

BUILD WITHOUT A COMPUTER (cloud build using GitHub):
1. Create a GitHub account if you do not already have one.
2. Create a new repository named IRIS-Android.
3. Upload the contents of this extracted project into the repository, keeping
   the folder structure (including the hidden .github/workflows/build-apk.yml).
4. Open the repository's Actions tab.
5. Choose "Build IRIS APK" and tap "Run workflow" (or push to main).
6. Wait for the workflow to finish successfully.
7. Open that workflow run, scroll to Artifacts, and download IRIS-debug-apk.
8. Extract the downloaded artifact ZIP; it contains app-debug.apk.
9. Open the APK on your Android phone and allow installation if Android asks.

The workflow builds the APK on GitHub-hosted cloud machines. Android Studio is
not required on your phone. A GitHub account and internet access are required.

The app loads the hosted website, so an internet connection is required.
Updates published to the Netlify site appear in the app without rebuilding the APK.
